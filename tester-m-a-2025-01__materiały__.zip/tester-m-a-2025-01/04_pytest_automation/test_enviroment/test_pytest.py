def test_franek_ma_kota():
    x = 1 + 1
    assert x == 2

def test_franek_ma_kota2():
    x = 1 + 1
    assert x == 2
