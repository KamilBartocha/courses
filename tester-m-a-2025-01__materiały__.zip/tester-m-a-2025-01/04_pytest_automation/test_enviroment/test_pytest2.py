def test_api_response():
    respose_code = 200
    # if respose_code == 200:
    #     print("PASS test")
    # else:
    #     raise AssertionError("FAIL")
    assert respose_code == 200