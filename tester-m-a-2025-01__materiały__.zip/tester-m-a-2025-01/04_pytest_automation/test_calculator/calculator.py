class Calculator:
    def add(a, b):
        return a + b

    def subtract(a, b):
        """Subtract b from a and return result"""
        return  a - b
