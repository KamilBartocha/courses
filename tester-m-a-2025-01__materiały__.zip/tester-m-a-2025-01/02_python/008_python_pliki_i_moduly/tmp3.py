# import math
# print(math.sqrt(9))
# x = math.pi
# print(x)

# import math as m
# x = m.pi

# from math import sqrt, pi, sin, cos

# y = sqrt()
# x = pi


from math import *

x = sqrt(3)
y = cos(3)

print(x)
print(y)

