import fruitmodule as fm

fm.lemon_number(5)

wynik = fm.sum_two_numbers()
print(wynik)



# a: import b
# b: import f, g


# ->> a ma dostęp do b, f ,g